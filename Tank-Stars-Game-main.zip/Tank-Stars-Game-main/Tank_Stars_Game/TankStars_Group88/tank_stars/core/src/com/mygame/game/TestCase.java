//package com.mygame.game;
//import org.junit.Test;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.jupiter.api.Assertions.*;
//
//
//public class TestCase {
//    @Test
//    public void firstTestCase(){
//        int ans = DeathMode.check_within(10,8,9);
//        assertEquals(1,ans);
//    }
//
//    @Test
//    public void secondTestCase(){
//        int ans = (int) DeathMode.check_distance(100, 50);
//        assertEquals(50,ans);
//    }
//    @Test
//    public void thirdTestCase(){
//        int ans = (int) Player.decreased40(60);
//        assertEquals(20, ans);
//    }
//    @Test
//    public void fourthTest(){
//        int ans = Terrain.compare(4,1);
//        assertEquals(1, ans);
//    }
//}
